d3.csv('ue_industry.csv', data => {

    // Define your scales and generator here.

    d3.select('#answer1')
        // append more elements here

});
