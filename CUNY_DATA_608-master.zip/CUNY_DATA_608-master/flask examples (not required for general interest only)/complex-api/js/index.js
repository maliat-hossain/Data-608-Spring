d3.json('hpi/NSA/San Francisco'.replace(' ', '%20'), function(json) {
  console.log(json);
});
